// Este script llena la base de datos con el catálogo real.
// Se corre con: npm run db:seed
// (create-next-app + prisma db push ya deben haberse ejecutado antes)

import { PrismaClient } from "@prisma/client";
import { collections, products } from "../src/data/catalog";

const prisma = new PrismaClient();

async function main() {
  console.log("Sembrando colecciones y productos...");

  for (const c of collections) {
    await prisma.collection.upsert({
      where: { slug: c.slug },
      update: { name: c.name, description: c.description, sortOrder: c.sortOrder },
      create: c,
    });
  }

  for (const p of products) {
    const collection = await prisma.collection.findUniqueOrThrow({
      where: { slug: p.collectionSlug },
    });

    await prisma.product.upsert({
      where: { slug: p.slug },
      update: {
        name: p.name,
        subtitle: p.subtitle,
        description: p.description,
        finish: p.finish,
        toneBase: p.toneBase,
        vein: p.vein,
        usage: p.usage,
        thicknessMm: p.thicknessMm,
        pricePerM2: p.pricePerM2,
        priceConfirmed: p.priceConfirmed,
        imageUrl: `/images/products/${p.slug}.webp`,
        thumbUrl: `/images/products/${p.slug}-thumb.webp`,
        featured: p.featured ?? false,
        collectionId: collection.id,
      },
      create: {
        slug: p.slug,
        name: p.name,
        subtitle: p.subtitle,
        description: p.description,
        finish: p.finish,
        toneBase: p.toneBase,
        vein: p.vein,
        usage: p.usage,
        thicknessMm: p.thicknessMm,
        pricePerM2: p.pricePerM2,
        priceConfirmed: p.priceConfirmed,
        imageUrl: `/images/products/${p.slug}.webp`,
        thumbUrl: `/images/products/${p.slug}-thumb.webp`,
        featured: p.featured ?? false,
        collectionId: collection.id,
      },
    });
  }

  console.log(`Listo: ${collections.length} colecciones, ${products.length} productos.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
