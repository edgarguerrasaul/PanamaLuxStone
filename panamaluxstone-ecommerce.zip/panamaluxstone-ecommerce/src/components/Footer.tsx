export default function Footer() {
  return (
    <footer id="contacto" className="border-t border-neutral-200 bg-neutral-950 text-neutral-300">
      <div className="container-app grid gap-8 py-12 sm:grid-cols-3">
        <div>
          <p className="font-serif text-lg text-white">GUERRA Materiales</p>
          <p className="mt-2 text-sm text-neutral-400">
            Piedra sinterizada, mármol y granito para proyectos residenciales y comerciales en toda Panamá.
          </p>
        </div>
        <div>
          <p className="text-sm font-semibold text-white">Contacto</p>
          <ul className="mt-2 space-y-1 text-sm text-neutral-400">
            <li>WhatsApp: [pendiente de definir]</li>
            <li>Correo: ventas@panamaluxstone.com</li>
            <li>Ciudad de Panamá, Panamá</li>
          </ul>
        </div>
        <div>
          <p className="text-sm font-semibold text-white">Enlaces</p>
          <ul className="mt-2 space-y-1 text-sm text-neutral-400">
            <li>
              <a href="/catalogo" className="hover:text-white">
                Catálogo
              </a>
            </li>
            <li>
              <a href="/cotizador" className="hover:text-white">
                Cotizador
              </a>
            </li>
          </ul>
        </div>
      </div>
      <p className="border-t border-neutral-800 py-4 text-center text-xs text-neutral-500">
        © {new Date().getFullYear()} GUERRA Materiales. Todos los derechos reservados.
      </p>
    </footer>
  );
}
