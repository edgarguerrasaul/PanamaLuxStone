import Image from "next/image";
import Link from "next/link";

export interface ProductCardData {
  slug: string;
  name: string;
  subtitle: string;
  imageUrl: string;
  thumbUrl: string;
  pricePerM2: number;
  priceConfirmed: boolean;
}

export default function ProductCard({ product }: { product: ProductCardData }) {
  return (
    <Link
      href={`/catalogo/${product.slug}`}
      className="group block overflow-hidden rounded-lg border border-neutral-200 transition hover:shadow-lg"
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-neutral-100">
        <Image
          src={product.thumbUrl}
          alt={product.name}
          fill
          sizes="(max-width: 768px) 50vw, 25vw"
          className="object-cover transition duration-300 group-hover:scale-105"
        />
      </div>
      <div className="p-4">
        <p className="text-xs uppercase tracking-wide text-neutral-500">{product.subtitle}</p>
        <h3 className="mt-1 font-medium text-neutral-900">{product.name}</h3>
        <p className="mt-2 text-sm text-neutral-700">
          ${product.pricePerM2}/m²{" "}
          {!product.priceConfirmed && <span className="text-xs text-amber-600">(precio por confirmar)</span>}
        </p>
      </div>
    </Link>
  );
}
