"use client";

import { useState } from "react";
import { useCart } from "@/lib/cart/store";

export default function AddToCartButton({
  product,
}: {
  product: { productId: string; slug: string; name: string; imageUrl: string; pricePerM2: number };
}) {
  const addItem = useCart((s) => s.addItem);
  const [area, setArea] = useState(5.12); // una placa estándar por defecto
  const [added, setAdded] = useState(false);

  return (
    <div className="flex items-center gap-3">
      <label className="flex items-center gap-2 text-sm">
        m²
        <input
          type="number"
          min={0.1}
          step={0.1}
          value={area}
          onChange={(e) => setArea(Number(e.target.value))}
          className="w-20 rounded border border-neutral-300 px-2 py-1"
        />
      </label>
      <button
        className="btn-primary"
        onClick={() => {
          addItem({ ...product, areaM2: area });
          setAdded(true);
          setTimeout(() => setAdded(false), 1500);
        }}
      >
        {added ? "Agregado ✓" : "Agregar al carrito"}
      </button>
    </div>
  );
}
