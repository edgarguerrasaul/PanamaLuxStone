"use client";

import { useMemo, useState } from "react";

type Product = { id: string; name: string; pricePerM2: number; priceConfirmed: boolean };

const SURFACES = [
  { key: "encimera", label: "Encimera / Superficie de trabajo" },
  { key: "frentes", label: "Frentes / Bordes laterales" },
  { key: "zocalos", label: "Zócalos" },
  { key: "salpicadero", label: "Rebosadero / Salpicadero" },
  { key: "isla", label: "Isla (si aplica)" },
  { key: "otra", label: "Otra superficie" },
];

export default function QuoteCalculator({ products }: { products: Product[] }) {
  const [step, setStep] = useState(1);
  const [measurements, setMeasurements] = useState<Record<string, number>>({});
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [productId, setProductId] = useState<string | null>(null);
  const [contactEmail, setContactEmail] = useState("");
  const [contactPhone, setContactPhone] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<{ areaTotalM2: number; estimatedTotal: number } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const areaTotal = useMemo(() => Object.values(measurements).reduce((sum, v) => sum + (v || 0), 0), [measurements]);
  const selectedProduct = products.find((p) => p.id === productId);
  const estimate = selectedProduct ? areaTotal * selectedProduct.pricePerM2 : 0;

  async function handlePhotoUpload(file: File) {
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: formData });
      const data = await res.json();
      if (res.ok) setPhotoUrl(data.url);
    } finally {
      setUploading(false);
    }
  }

  async function handleSubmit() {
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/quotes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contactEmail, contactPhone, productId, measurements, photoUrl }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "No se pudo enviar la cotización.");
        return;
      }
      setResult({ areaTotalM2: data.areaTotalM2, estimatedTotal: data.estimatedTotal });
    } catch {
      setError("Hubo un problema de conexión. Intenta de nuevo.");
    } finally {
      setSubmitting(false);
    }
  }

  if (result) {
    return (
      <div className="mt-10 max-w-lg rounded-lg border border-neutral-200 p-8 text-center">
        <h2 className="font-serif text-2xl font-semibold">¡Listo!</h2>
        <p className="mt-2 text-neutral-600">
          Superficie total: <strong>{result.areaTotalM2.toFixed(2)} m²</strong>
        </p>
        <p className="mt-1 text-3xl font-semibold text-gold-600">${result.estimatedTotal.toFixed(2)}</p>
        <p className="mt-4 text-sm text-neutral-500">
          Te enviamos el estimado a {contactEmail}. Un asesor te contactará en menos de 24 horas.
        </p>
      </div>
    );
  }

  return (
    <div className="mt-10 max-w-2xl">
      <div className="mb-8 flex gap-2 text-sm">
        {[1, 2, 3].map((n) => (
          <div
            key={n}
            className={`flex h-8 w-8 items-center justify-center rounded-full ${
              step >= n ? "bg-neutral-900 text-white" : "bg-neutral-200 text-neutral-500"
            }`}
          >
            {n}
          </div>
        ))}
      </div>

      {step === 1 && (
        <div className="space-y-4">
          <h2 className="font-medium">01 · Medidas y superficies</h2>
          <p className="text-sm text-neutral-500">Indica solo las superficies que apliquen a tu proyecto (en m²).</p>
          {SURFACES.map((s) => (
            <label key={s.key} className="flex items-center justify-between gap-4">
              <span className="text-sm">{s.label}</span>
              <input
                type="number"
                min={0}
                step={0.1}
                placeholder="0"
                className="w-24 rounded border border-neutral-300 px-2 py-1"
                onChange={(e) =>
                  setMeasurements((m) => ({ ...m, [s.key]: Number(e.target.value) }))
                }
              />
            </label>
          ))}
          <p className="text-sm text-neutral-500">
            Placa estándar: 1.6 × 3.2 m = 5.12 m² · Espesor: 12 mm
          </p>
          <button className="btn-primary" disabled={areaTotal <= 0} onClick={() => setStep(2)}>
            Siguiente
          </button>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-4">
          <h2 className="font-medium">02 · Sube tu foto</h2>
          <p className="text-sm text-neutral-500">
            Fotografía de buena calidad de tu cocina actual (opcional, pero ayuda a nuestro equipo de diseño).
          </p>
          <label className="flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-neutral-300 p-10 text-center">
            <span className="text-3xl">📷</span>
            <span className="mt-2 text-sm">{uploading ? "Subiendo..." : photoUrl ? "Foto lista ✓" : "Toca aquí para subir tu foto"}</span>
            <span className="mt-1 text-xs text-neutral-400">JPG, PNG — alta resolución recomendada</span>
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => e.target.files?.[0] && handlePhotoUpload(e.target.files[0])}
            />
          </label>
          <div className="flex gap-3">
            <button className="btn-secondary" onClick={() => setStep(1)}>
              Atrás
            </button>
            <button className="btn-primary" onClick={() => setStep(3)}>
              Siguiente
            </button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-4">
          <h2 className="font-medium">03 · Escoge tu piedra</h2>
          <div className="grid max-h-64 grid-cols-2 gap-2 overflow-y-auto rounded border border-neutral-200 p-2">
            {products.map((p) => (
              <button
                key={p.id}
                onClick={() => setProductId(p.id)}
                className={`rounded border px-3 py-2 text-left text-sm ${
                  productId === p.id ? "border-neutral-900 bg-neutral-50" : "border-neutral-200"
                }`}
              >
                <p className="font-medium">{p.name}</p>
                <p className="text-xs text-neutral-500">${p.pricePerM2}/m²</p>
              </button>
            ))}
          </div>

          {estimate > 0 && (
            <p className="text-lg font-semibold">
              Estimado: <span className="text-gold-600">${estimate.toFixed(2)}</span> ({areaTotal.toFixed(2)} m²)
            </p>
          )}

          <div className="grid gap-3 sm:grid-cols-2">
            <input
              required
              type="email"
              placeholder="Tu correo"
              value={contactEmail}
              onChange={(e) => setContactEmail(e.target.value)}
              className="rounded border border-neutral-300 px-3 py-2"
            />
            <input
              placeholder="Teléfono / WhatsApp"
              value={contactPhone}
              onChange={(e) => setContactPhone(e.target.value)}
              className="rounded border border-neutral-300 px-3 py-2"
            />
          </div>

          {error && <p className="text-sm text-red-600">{error}</p>}

          <div className="flex gap-3">
            <button className="btn-secondary" onClick={() => setStep(2)}>
              Atrás
            </button>
            <button
              className="btn-primary"
              disabled={!productId || !contactEmail || submitting}
              onClick={handleSubmit}
            >
              {submitting ? "Enviando..." : "Calcular cotización"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
