// Catálogo real de GUERRA Materiales, tomado del catálogo 2025/2026
// existente (catalogo_piedras_sinterizadas.html) y de las fotos del
// proyecto. Esto es la "fuente de la verdad" que se usa para poblar
// la base de datos (prisma/seed.ts) y, si no hay base de datos aún,
// para mostrar el catálogo directamente.
//
// priceConfirmed: false  => precio estimado por Claude a partir de la
// categoría de la piedra; NO está confirmado en la lista de precios
// original y debe revisarse en la hoja de especificaciones.

export type CatalogCollection = {
  slug: string;
  name: string;
  description: string;
  sortOrder: number;
};

export type CatalogProduct = {
  slug: string;
  name: string;
  subtitle: string;
  description: string;
  finish: string;
  toneBase: string;
  vein: string;
  usage: string;
  thicknessMm: number;
  pricePerM2: number;
  priceConfirmed: boolean;
  collectionSlug: string;
  featured?: boolean;
};

export const collections: CatalogCollection[] = [
  {
    slug: "blancos-y-claros",
    name: "Tonos Blancos y Claros",
    description:
      "Mármoles y calacattas de gran formato en tonos blancos, marfil y beige. La colección más versátil, ideal para cocinas, baños y proyectos residenciales de alto volumen.",
    sortOrder: 1,
  },
  {
    slug: "tonos-oscuros",
    name: "Tonos Oscuros",
    description:
      "Grises antracita y negros con vetas dramáticas. Para cocinas y baños que buscan contraste y presencia.",
    sortOrder: 2,
  },
  {
    slug: "modelos-exoticos",
    name: "Modelos Exóticos",
    description:
      "Piezas de colección: madera sinterizada, ónice retroiluminado y acabados espejo. Para espacios signature de máximo impacto visual.",
    sortOrder: 3,
  },
];

export const products: CatalogProduct[] = [
  // ── Tonos Blancos y Claros ($95/m²) ──
  {
    slug: "alice-gold",
    name: "Alice Gold",
    subtitle: "Mármol Blanco Veteado",
    description:
      "Fondo blanco puro con finas venas doradas y carameladas que cruzan diagonalmente. Elegancia clásica de inspiración italiana, ideal para encimeras y revestimientos de lujo.",
    finish: "Pulido / Matt",
    toneBase: "Blanco marfil",
    vein: "Dorada / Caramel",
    usage: "Interior / Exterior",
    thicknessMm: 12,
    pricePerM2: 95,
    priceConfirmed: true,
    collectionSlug: "blancos-y-claros",
    featured: true,
  },
  {
    slug: "carrara-gold",
    name: "Carrara Gold",
    subtitle: "Clásico Italiano",
    description:
      "Recreación moderna del icónico mármol de Carrara enriquecida con venas doradas y grises. Compleja y pictórica, cada placa cuenta una historia geológica única.",
    finish: "Pulido / Matt",
    toneBase: "Blanco / Gris frío",
    vein: "Dorado / Óxido",
    usage: "Interior / Exterior",
    thicknessMm: 12,
    pricePerM2: 95,
    priceConfirmed: true,
    collectionSlug: "blancos-y-claros",
  },
  {
    slug: "gadal-calacatta-gold",
    name: "Gadal Calacatta Gold",
    subtitle: "Calacatta Premium",
    description:
      "Versión de gran formato del Calacatta gold con venas doradas anchas y expresivas sobre fondo blanco cremoso. El referente absoluto del lujo en cocinas y baños premium.",
    finish: "Pulido / Matt",
    toneBase: "Blanco crema",
    vein: "Dorado intenso",
    usage: "Interior / Exterior",
    thicknessMm: 12,
    pricePerM2: 95,
    priceConfirmed: true,
    collectionSlug: "blancos-y-claros",
    featured: true,
  },
  {
    slug: "hetian-jade",
    name: "Hetian Jade",
    subtitle: "Jade Chino Translúcido",
    description:
      "Inspirada en el jade de Hetian, la piedra más venerada de China. Fondo blanco nacarado con nubosidades suaves y venas doradas etéreas.",
    finish: "Pulido",
    toneBase: "Blanco nacarado",
    vein: "Dorado etéreo",
    usage: "Interior premium",
    thicknessMm: 12,
    pricePerM2: 95,
    priceConfirmed: true,
    collectionSlug: "blancos-y-claros",
  },
  {
    slug: "ink-white",
    name: "Ink White",
    subtitle: "Blanco Satinado",
    description:
      "Blanco inmaculado con finas venas grises que se deslizan en paralelo con elegancia minimalista. Ideal para baños de lujo y cocinas de estética nórdica.",
    finish: "Pulido",
    toneBase: "Blanco puro",
    vein: "Gris plata sutil",
    usage: "Interior y Exterior",
    thicknessMm: 12,
    pricePerM2: 95,
    priceConfirmed: true,
    collectionSlug: "blancos-y-claros",
  },
  {
    slug: "louis-gold",
    name: "Louis Gold",
    subtitle: "Calacatta Dorado",
    description:
      "Fondo blanco con venas doradas anchas y fluidas de marcado carácter. Reminiscencia del lujo rococó francés reinterpretado en formato sinterizado.",
    finish: "Pulido / Matt",
    toneBase: "Blanco nácar",
    vein: "Dorado ámbar",
    usage: "Interior y Exterior",
    thicknessMm: 12,
    pricePerM2: 95,
    priceConfirmed: true,
    collectionSlug: "blancos-y-claros",
  },
  {
    slug: "new-snow-stone",
    name: "New Snow Stone",
    subtitle: "Blanco Nieve Polished",
    description:
      "Blanco níveo con venas grises de trazado fluido y orgánico. La pureza de la nieve recién caída capturada en una superficie sinterizada uniforme.",
    finish: "Pulido",
    toneBase: "Blanco nieve",
    vein: "Gris humo",
    usage: "Interior y Exterior",
    thicknessMm: 12,
    pricePerM2: 95,
    priceConfirmed: true,
    collectionSlug: "blancos-y-claros",
  },
  {
    slug: "premium-taj-mahal",
    name: "Premium Taj Mahal",
    subtitle: "Beige Premium",
    description:
      "Inspirada en la cuarcita brasileña Taj Mahal, en tonos arena cálidos con venas doradas. Calidez y sofisticación para suelos, paredes y encimeras.",
    finish: "Pulido",
    toneBase: "Beige arena cálido",
    vein: "Dorado / Caramel",
    usage: "Interior y Exterior",
    thicknessMm: 12,
    pricePerM2: 95,
    priceConfirmed: true,
    collectionSlug: "blancos-y-claros",
  },
  {
    slug: "roman-beige-cave-stone",
    name: "Roman Beige Cave Stone",
    subtitle: "Piedra Caliza Romana",
    description:
      "Piedra caliza de inspiración romana con bandas horizontales uniformes que evocan capas sedimentarias. Calidez mediterránea para arquitectura clásica o biofílica.",
    finish: "Pulido",
    toneBase: "Beige crema suave",
    vein: "Arena / Topo",
    usage: "Interior y Exterior",
    thicknessMm: 12,
    pricePerM2: 95,
    priceConfirmed: true,
    collectionSlug: "blancos-y-claros",
  },
  {
    slug: "royal-calacatta-white",
    name: "Royal Calacatta White",
    subtitle: "Calacatta Real",
    description:
      "Calacatta de gran formato con venas grises de trazo amplio y seguro. Movimiento continuo entre placas, ideal para revestimientos de libro abierto.",
    finish: "Pulido / Matt",
    toneBase: "Blanco luminoso",
    vein: "Gris plateado",
    usage: "Interior y Exterior",
    thicknessMm: 12,
    pricePerM2: 95,
    priceConfirmed: true,
    collectionSlug: "blancos-y-claros",
  },
  {
    slug: "saturnia",
    name: "Saturnia",
    subtitle: "Travertino Moderno",
    description:
      "Inspirada en el travertino de Saturnia con venas grises azuladas de carácter arquitectónico. Sofisticación atemporal entre tradición y modernidad.",
    finish: "Pulido / Matt",
    toneBase: "Blanco / Gris frío",
    vein: "Gris azulado",
    usage: "Interior y Exterior",
    thicknessMm: 12,
    pricePerM2: 95,
    priceConfirmed: true,
    collectionSlug: "blancos-y-claros",
  },
  {
    slug: "victoria-white",
    name: "Victoria White",
    subtitle: "Calacatta Victoria",
    description:
      "Blanco glacial con venas grises de trazo expresivo y nódulos de mayor densidad visual. Elegancia monumental para revestimientos continuos de gran formato.",
    finish: "Pulido / Matt",
    toneBase: "Blanco glacial",
    vein: "Gris expresivo",
    usage: "Interior y Exterior",
    thicknessMm: 12,
    pricePerM2: 95,
    priceConfirmed: true,
    collectionSlug: "blancos-y-claros",
  },

  // ── Tonos Oscuros ($92/m²) ──
  {
    slug: "armani-dark-grey",
    name: "Armani Dark Grey",
    subtitle: "Piedra Oscura Premium",
    description:
      "Gris antracita profundo con finas venas blancas que crean un movimiento sutil y sofisticado. Inspirado en la estética Pietra di Cardoso.",
    finish: "Pulido / Matt",
    toneBase: "Gris antracita",
    vein: "Blanco sutil",
    usage: "Interior / Exterior",
    thicknessMm: 12,
    pricePerM2: 92,
    priceConfirmed: true,
    collectionSlug: "tonos-oscuros",
    featured: true,
  },
  {
    slug: "armani-light-grey",
    name: "Armani Light Grey",
    subtitle: "Piedra Gris Clara",
    description:
      "Gris medio luminoso con textura de piedra natural fósil y venas blancas bien definidas. Versatilidad máxima con paletas neutras o acentos de color.",
    finish: "Pulido / Matt",
    toneBase: "Gris perla",
    vein: "Blanco / Gris",
    usage: "Interior / Exterior",
    thicknessMm: 12,
    pricePerM2: 92,
    priceConfirmed: true,
    collectionSlug: "tonos-oscuros",
  },
  {
    slug: "carmen-black",
    name: "Carmen Black",
    subtitle: "Negro Absoluto Veteado",
    description:
      "Negro profundo con dramáticas venas blancas que recorren la superficie como relámpagos. Inspirado en el Marquina negro, máximo contraste.",
    finish: "Pulido / Matt",
    toneBase: "Negro intenso",
    vein: "Blanco dramático",
    usage: "Interior / Exterior",
    thicknessMm: 12,
    pricePerM2: 92,
    priceConfirmed: true,
    collectionSlug: "tonos-oscuros",
  },
  {
    slug: "dini-saint-castle-dark-grey",
    name: "Dini Saint Castle Dark Grey",
    subtitle: "Piedra Gris Oscuro",
    description:
      "Gris pizarra oscuro con rica trama de microvenas blancas que crean un efecto casi nebuloso. Evoca la solidez de la piedra de castillo medieval.",
    finish: "Pulido",
    toneBase: "Gris pizarra",
    vein: "Blanco nebuloso",
    usage: "Interior / Exterior",
    thicknessMm: 12,
    pricePerM2: 92,
    priceConfirmed: true,
    collectionSlug: "tonos-oscuros",
  },

  // ── Modelos Exóticos ($108/m², Starry Blue por confirmar) ──
  {
    slug: "egg-wood-grain",
    name: "Egg Wood Grain",
    subtitle: "Madera Sinterizada",
    description:
      "Imitación madera de nogal oscuro con veta longitudinal continua y tallado artístico en relieve. La calidez de la madera con la durabilidad de la piedra.",
    finish: "Tallado / Relieve",
    toneBase: "Marrón chocolate",
    vein: "Veta de madera",
    usage: "Interior",
    thicknessMm: 12,
    pricePerM2: 108,
    priceConfirmed: true,
    collectionSlug: "modelos-exoticos",
  },
  {
    slug: "golden-brocade-brown-sand",
    name: "Golden Brocade Brown Sand",
    subtitle: "Ónice Cálido",
    description:
      "Explosión cromática de ámbar, naranja y marrón tostado con bandas horizontales que evocan capas geológicas. Efecto ónice retroiluminado.",
    finish: "Pulido translúcido",
    toneBase: "Ámbar / Naranja",
    vein: "Bandas geológicas",
    usage: "Interior / Retroiluminado",
    thicknessMm: 12,
    pricePerM2: 108,
    priceConfirmed: true,
    collectionSlug: "modelos-exoticos",
  },
  {
    slug: "prada-green",
    name: "Prada Green",
    subtitle: "Piedra Verde Oscura",
    description:
      "Fondo negro volcánico surcado por dramáticas venas verde jade y blanco cristal. Una pieza de colección de extraordinaria personalidad.",
    finish: "Pulido",
    toneBase: "Negro / Verde oscuro",
    vein: "Verde jade / Blanco",
    usage: "Interior y Exterior",
    thicknessMm: 12,
    pricePerM2: 108,
    priceConfirmed: true,
    collectionSlug: "modelos-exoticos",
    featured: true,
  },
  {
    slug: "starry-blue",
    name: "Starry Blue",
    subtitle: "Azul Estelar Espejo",
    description:
      "Azul noche con ríos de dorado y blanco que crean un efecto galáctico único. Acabado espejo de alta reflectividad para espacios signature de máximo lujo.",
    finish: "Espejo / Glaze",
    toneBase: "Azul noche profundo",
    vein: "Dorado / Blanco",
    usage: "Interior premium",
    thicknessMm: 12,
    pricePerM2: 125,
    // Este modelo no traía precio en la lista original del cotizador
    // (los otros 3 exóticos sí). Se estimó igual que la categoría exótica
    // + 15% por ser acabado espejo premium. CONFIRMAR precio real.
    priceConfirmed: false,
    collectionSlug: "modelos-exoticos",
    featured: true,
  },
];

export const PLATE_WIDTH_M = 1.6;
export const PLATE_HEIGHT_M = 3.2;
export const PLATE_AREA_M2 = PLATE_WIDTH_M * PLATE_HEIGHT_M; // 5.12 m²
