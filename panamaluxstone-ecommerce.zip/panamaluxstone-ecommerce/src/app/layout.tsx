import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "GUERRA Materiales — Piedra Sinterizada, Mármol y Granito en Panamá",
  description:
    "Distribuidor de piedra sinterizada, mármol y granito en Panamá. Cotiza tu cocina en minutos, elige entre 20 modelos y paga en línea.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="es">
      <body className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
