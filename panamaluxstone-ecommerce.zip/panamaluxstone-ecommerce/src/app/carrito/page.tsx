"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useCart } from "@/lib/cart/store";

export default function CarritoPage() {
  const [mounted, setMounted] = useState(false);
  const { items, removeItem, updateArea, total } = useCart();

  useEffect(() => setMounted(true), []);

  if (!mounted) return null;

  if (items.length === 0) {
    return (
      <div className="container-app py-20 text-center">
        <h1 className="font-serif text-2xl font-semibold">Tu carrito está vacío</h1>
        <Link href="/catalogo" className="btn-primary mt-6 inline-flex">
          Ver catálogo
        </Link>
      </div>
    );
  }

  return (
    <div className="container-app py-12">
      <h1 className="font-serif text-3xl font-semibold">Tu carrito</h1>

      <div className="mt-8 space-y-4">
        {items.map((item) => (
          <div key={item.productId} className="flex items-center gap-4 rounded-lg border border-neutral-200 p-4">
            <div className="relative h-20 w-20 overflow-hidden rounded bg-neutral-100">
              <Image src={item.imageUrl} alt={item.name} fill className="object-cover" />
            </div>
            <div className="flex-1">
              <p className="font-medium">{item.name}</p>
              <p className="text-sm text-neutral-500">${item.pricePerM2}/m²</p>
            </div>
            <label className="flex items-center gap-2 text-sm">
              m²
              <input
                type="number"
                min={0.1}
                step={0.1}
                value={item.areaM2}
                onChange={(e) => updateArea(item.productId, Number(e.target.value))}
                className="w-20 rounded border border-neutral-300 px-2 py-1"
              />
            </label>
            <p className="w-24 text-right font-medium">${(item.areaM2 * item.pricePerM2).toFixed(2)}</p>
            <button onClick={() => removeItem(item.productId)} className="text-sm text-neutral-400 hover:text-red-600">
              Quitar
            </button>
          </div>
        ))}
      </div>

      <div className="mt-8 flex items-center justify-between border-t border-neutral-200 pt-6">
        <p className="text-lg font-semibold">Total estimado: ${total().toFixed(2)}</p>
        <Link href="/checkout" className="btn-primary">
          Continuar al pago
        </Link>
      </div>
      <p className="mt-2 text-xs text-neutral-500">
        El total final puede variar tras la medición en sitio (cortes, desperdicio de placa e instalación).
      </p>
    </div>
  );
}
