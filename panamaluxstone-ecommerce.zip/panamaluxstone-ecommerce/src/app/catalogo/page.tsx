import { db } from "@/lib/db";
import ProductCard from "@/components/ProductCard";

export const revalidate = 3600;

export default async function CatalogoPage({
  searchParams,
}: {
  searchParams: Promise<{ coleccion?: string }>;
}) {
  const collections = await db.collection.findMany({ orderBy: { sortOrder: "asc" } });
  const { coleccion: activeSlug } = await searchParams;

  const products = await db.product.findMany({
    where: activeSlug ? { collection: { slug: activeSlug } } : undefined,
    include: { collection: true },
    orderBy: { name: "asc" },
  });

  return (
    <div className="container-app py-12">
      <h1 className="font-serif text-3xl font-semibold">Catálogo</h1>
      <p className="mt-2 text-neutral-600">20 modelos · 12mm de espesor · acabados pulido, matt y especiales.</p>

      <div className="mt-6 flex flex-wrap gap-2">
        <a
          href="/catalogo"
          className={`rounded-full border px-4 py-1.5 text-sm ${
            !activeSlug ? "border-neutral-900 bg-neutral-900 text-white" : "border-neutral-300"
          }`}
        >
          Todos
        </a>
        {collections.map((c) => (
          <a
            key={c.slug}
            href={`/catalogo?coleccion=${c.slug}`}
            className={`rounded-full border px-4 py-1.5 text-sm ${
              activeSlug === c.slug ? "border-neutral-900 bg-neutral-900 text-white" : "border-neutral-300"
            }`}
          >
            {c.name}
          </a>
        ))}
      </div>

      <div className="mt-8 grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-4">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>

      {products.length === 0 && (
        <p className="mt-10 text-sm text-neutral-500">
          No hay productos todavía. Corre <code>npm run db:seed</code> para cargar el catálogo real.
        </p>
      )}
    </div>
  );
}
