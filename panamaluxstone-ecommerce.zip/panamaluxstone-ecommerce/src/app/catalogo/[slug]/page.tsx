import { notFound } from "next/navigation";
import Image from "next/image";
import { db } from "@/lib/db";
import AddToCartButton from "@/components/AddToCartButton";

export const revalidate = 3600;

export async function generateStaticParams() {
  const products = await db.product.findMany({ select: { slug: true } });
  return products.map((p) => ({ slug: p.slug }));
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = await db.product.findUnique({
    where: { slug },
    include: { collection: true },
  });

  if (!product) notFound();

  const specs = [
    { label: "Acabado", value: product.finish },
    { label: "Tono base", value: product.toneBase },
    { label: "Veta", value: product.vein },
    { label: "Espesor", value: `${product.thicknessMm} mm` },
    { label: "Uso recomendado", value: product.usage },
    { label: "Colección", value: product.collection.name },
  ];

  return (
    <div className="container-app grid gap-10 py-12 sm:grid-cols-2">
      <div className="relative aspect-square overflow-hidden rounded-lg bg-neutral-100">
        <Image src={product.imageUrl} alt={product.name} fill priority className="object-cover" />
      </div>

      <div>
        <p className="text-sm uppercase tracking-wide text-neutral-500">{product.subtitle}</p>
        <h1 className="mt-1 font-serif text-3xl font-semibold">{product.name}</h1>
        <p className="mt-4 text-2xl font-medium text-gold-600">
          ${product.pricePerM2}/m²
          {!product.priceConfirmed && (
            <span className="ml-2 text-sm font-normal text-amber-600">(precio estimado, por confirmar)</span>
          )}
        </p>
        <p className="mt-6 text-neutral-700">{product.description}</p>

        <dl className="mt-8 grid grid-cols-2 gap-4 border-t border-neutral-200 pt-6 text-sm">
          {specs.map((s) => (
            <div key={s.label}>
              <dt className="text-neutral-500">{s.label}</dt>
              <dd className="font-medium">{s.value}</dd>
            </div>
          ))}
        </dl>

        <div className="mt-8 flex flex-wrap gap-4">
          <AddToCartButton
            product={{
              productId: product.id,
              slug: product.slug,
              name: product.name,
              imageUrl: product.imageUrl,
              pricePerM2: product.pricePerM2,
            }}
          />
          <a href="/cotizador" className="btn-secondary">
            Cotizar con esta piedra
          </a>
        </div>
      </div>
    </div>
  );
}
