"use client";

import { useEffect, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { useCart } from "@/lib/cart/store";

const PAYMENT_METHODS = [
  { id: "yappy", label: "Yappy", hint: "Pago instantáneo desde tu celular" },
  { id: "card", label: "Tarjeta", hint: "Visa / Mastercard" },
  { id: "transfer", label: "Transferencia", hint: "Ideal para pedidos de empresas" },
] as const;

export default function CheckoutPage() {
  const router = useRouter();
  const { items, total, clear } = useCart();
  const [mounted, setMounted] = useState(false);
  const [method, setMethod] = useState<(typeof PAYMENT_METHODS)[number]["id"]>("yappy");
  const [form, setForm] = useState({ name: "", email: "", phone: "", address: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => setMounted(true), []);
  if (!mounted) return null;

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customer: { name: form.name, email: form.email, phone: form.phone },
          paymentMethod: method,
          shippingAddress: form.address,
          items: items.map((i) => ({ productId: i.productId, areaM2: i.areaM2 })),
        }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error ?? "No se pudo procesar el pedido.");
        return;
      }

      clear();
      if (data.redirectUrl) {
        window.location.href = data.redirectUrl;
      } else {
        router.push(`/checkout/gracias?order=${data.orderId}`);
      }
    } catch {
      setError("Hubo un problema de conexión. Intenta de nuevo.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="container-app grid gap-10 py-12 sm:grid-cols-2">
      <form onSubmit={handleSubmit} className="space-y-4">
        <h1 className="font-serif text-2xl font-semibold">Datos de contacto</h1>
        <input
          required
          placeholder="Nombre completo"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="w-full rounded border border-neutral-300 px-3 py-2"
        />
        <input
          required
          type="email"
          placeholder="Correo"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          className="w-full rounded border border-neutral-300 px-3 py-2"
        />
        <input
          placeholder="Teléfono / WhatsApp"
          value={form.phone}
          onChange={(e) => setForm({ ...form, phone: e.target.value })}
          className="w-full rounded border border-neutral-300 px-3 py-2"
        />
        <input
          placeholder="Dirección de instalación (opcional)"
          value={form.address}
          onChange={(e) => setForm({ ...form, address: e.target.value })}
          className="w-full rounded border border-neutral-300 px-3 py-2"
        />

        <div>
          <p className="mb-2 text-sm font-medium">Método de pago</p>
          <div className="grid grid-cols-3 gap-2">
            {PAYMENT_METHODS.map((m) => (
              <button
                type="button"
                key={m.id}
                onClick={() => setMethod(m.id)}
                className={`rounded border px-3 py-3 text-left text-sm ${
                  method === m.id ? "border-neutral-900 bg-neutral-50" : "border-neutral-300"
                }`}
              >
                <p className="font-medium">{m.label}</p>
                <p className="text-xs text-neutral-500">{m.hint}</p>
              </button>
            ))}
          </div>
        </div>

        {error && <p className="text-sm text-red-600">{error}</p>}

        <button type="submit" disabled={loading || items.length === 0} className="btn-primary w-full">
          {loading ? "Procesando..." : `Pagar $${total().toFixed(2)}`}
        </button>
      </form>

      <div>
        <h2 className="font-serif text-xl font-semibold">Resumen del pedido</h2>
        <ul className="mt-4 space-y-2 text-sm">
          {items.map((i) => (
            <li key={i.productId} className="flex justify-between">
              <span>
                {i.name} — {i.areaM2} m²
              </span>
              <span>${(i.areaM2 * i.pricePerM2).toFixed(2)}</span>
            </li>
          ))}
        </ul>
        <div className="mt-4 flex justify-between border-t border-neutral-200 pt-4 font-semibold">
          <span>Total</span>
          <span>${total().toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
}
