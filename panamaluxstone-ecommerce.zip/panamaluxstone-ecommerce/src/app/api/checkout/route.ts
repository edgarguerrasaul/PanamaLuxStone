// POST /api/checkout
// Recibe el carrito + datos del cliente + método de pago elegido,
// crea el pedido en la base de datos y arranca el cobro a través del
// middleware de pagos (src/lib/payments). Devuelve a dónde redirigir
// al cliente para completar el pago (si aplica).
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { getPaymentProvider, type PaymentMethodId } from "@/lib/payments";

const checkoutSchema = z.object({
  customer: z.object({
    name: z.string().min(2),
    email: z.string().email(),
    phone: z.string().optional(),
  }),
  paymentMethod: z.enum(["yappy", "card", "transfer"]),
  items: z
    .array(
      z.object({
        productId: z.string(),
        areaM2: z.number().positive(),
      })
    )
    .min(1),
  shippingAddress: z.string().optional(),
  notes: z.string().optional(),
});

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const parsed = checkoutSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Datos inválidos", details: parsed.error.flatten() }, { status: 400 });
  }
  const { customer, paymentMethod, items, shippingAddress, notes } = parsed.data;

  const products = await db.product.findMany({ where: { id: { in: items.map((i) => i.productId) } } });
  if (products.length !== items.length) {
    return NextResponse.json({ error: "Uno o más productos ya no existen." }, { status: 400 });
  }

  const orderItemsData = items.map((item) => {
    const product = products.find((p) => p.id === item.productId)!;
    return {
      productId: product.id,
      areaM2: item.areaM2,
      unitPrice: product.pricePerM2,
      subtotal: Number((product.pricePerM2 * item.areaM2).toFixed(2)),
    };
  });
  const totalAmount = Number(orderItemsData.reduce((sum, i) => sum + i.subtotal, 0).toFixed(2));

  const dbCustomer = await db.customer.upsert({
    where: { email: customer.email },
    update: { name: customer.name, phone: customer.phone },
    create: { name: customer.name, email: customer.email, phone: customer.phone },
  });

  const order = await db.order.create({
    data: {
      customerId: dbCustomer.id,
      paymentMethod: paymentMethod.toUpperCase() as "YAPPY" | "CARD" | "TRANSFER",
      totalAmount,
      shippingAddress,
      notes,
      items: { create: orderItemsData },
    },
  });

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? req.nextUrl.origin;

  try {
    const provider = getPaymentProvider(paymentMethod as PaymentMethodId);
    const payment = await provider.createPayment({
      orderId: order.id,
      amountCents: Math.round(totalAmount * 100),
      currency: "USD",
      customerEmail: customer.email,
      customerName: customer.name,
      description: `Pedido GUERRA Materiales #${order.id.slice(-6).toUpperCase()}`,
      returnUrl: `${siteUrl}/checkout/gracias?order=${order.id}`,
      cancelUrl: `${siteUrl}/carrito`,
    });

    await db.order.update({ where: { id: order.id }, data: { providerRef: payment.providerReference } });

    // Pago manual (transferencia): no hay redirección, el pedido queda
    // pendiente de confirmar y se le avisa igual al cliente por correo.
    if (payment.status === "requires_manual_confirmation") {
      await db.emailLog.create({ data: { to: customer.email, type: "ORDER_CONFIRMATION", orderId: order.id } });
    }

    return NextResponse.json({ ok: true, orderId: order.id, redirectUrl: payment.redirectUrl ?? null });
  } catch (err) {
    console.error("Error creando el pago:", err);
    return NextResponse.json(
      { ok: false, orderId: order.id, error: "No se pudo iniciar el pago. El pedido quedó guardado como pendiente." },
      { status: 502 }
    );
  }
}
