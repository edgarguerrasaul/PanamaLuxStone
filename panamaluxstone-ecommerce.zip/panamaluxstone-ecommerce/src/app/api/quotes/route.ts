// POST /api/quotes
// Guarda una cotización armada desde /cotizador (medidas + foto + piedra
// elegida) y agenda el correo de "recibimos tu cotización".
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";

const quoteSchema = z.object({
  contactEmail: z.string().email(),
  contactPhone: z.string().optional(),
  productId: z.string().optional(),
  measurements: z.record(z.number()), // { encimera: 4.2, frentes: 1.1, isla: 3.0, ... }
  photoUrl: z.string().optional(),
  wantsRender: z.boolean().optional(),
});

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const parsed = quoteSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Datos inválidos", details: parsed.error.flatten() }, { status: 400 });
  }
  const { contactEmail, contactPhone, productId, measurements, photoUrl, wantsRender } = parsed.data;

  const areaTotalM2 = Object.values(measurements).reduce((sum, v) => sum + v, 0);

  let estimatedTotal = 0;
  if (productId) {
    const product = await db.product.findUnique({ where: { id: productId } });
    if (product) estimatedTotal = Number((product.pricePerM2 * areaTotalM2).toFixed(2));
  }

  const quote = await db.quote.create({
    data: {
      contactEmail,
      contactPhone,
      productId,
      measurements: JSON.stringify(measurements),
      areaTotalM2,
      estimatedTotal,
      photoUrl,
      wantsRender: wantsRender ?? false,
    },
  });

  await db.emailLog.create({
    data: { to: contactEmail, type: "QUOTE_RECEIVED", quoteId: quote.id },
  });

  return NextResponse.json({ ok: true, quoteId: quote.id, areaTotalM2, estimatedTotal });
}
