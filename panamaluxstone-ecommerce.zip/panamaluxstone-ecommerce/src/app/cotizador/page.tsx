import { db } from "@/lib/db";
import QuoteCalculator from "@/components/QuoteCalculator";

export const revalidate = 3600;

export default async function CotizadorPage() {
  const products = await db.product.findMany({
    orderBy: [{ collection: { sortOrder: "asc" } }, { name: "asc" }],
    select: { id: true, name: true, pricePerM2: true, priceConfirmed: true },
  });

  return (
    <div className="container-app py-12">
      <h1 className="font-serif text-3xl font-semibold">Diseña tu cocina en 3 pasos</h1>
      <p className="mt-2 text-neutral-600">
        Mide tus superficies, sube una foto y elige tu piedra. Te damos un estimado al instante.
      </p>
      <QuoteCalculator products={products} />
    </div>
  );
}
