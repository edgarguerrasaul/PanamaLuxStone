import Link from "next/link";
import Image from "next/image";
import { db } from "@/lib/db";
import ProductCard from "@/components/ProductCard";

export const revalidate = 3600; // la home se regenera sola cada hora (rápida siempre, datos casi al día)

export default async function HomePage() {
  const featured = await db.product.findMany({ where: { featured: true }, take: 4 });

  return (
    <div>
      <section className="relative flex min-h-[70vh] items-center justify-center overflow-hidden bg-neutral-950 text-white">
        <div className="container-app relative z-10 py-24 text-center">
          <p className="text-sm uppercase tracking-[0.3em] text-gold-400">Piedra sinterizada · Mármol · Granito</p>
          <h1 className="mt-4 font-serif text-4xl font-semibold sm:text-6xl">Superficies de Excepción</h1>
          <p className="mx-auto mt-6 max-w-xl text-neutral-300">
            20 modelos disponibles para distribución en Panamá. Cotiza tu cocina en minutos y recibe tu superficie
            lista para instalar.
          </p>
          <div className="mt-10 flex flex-wrap justify-center gap-4">
            <Link href="/cotizador" className="btn-primary">
              Cotizar mi cocina
            </Link>
            <Link href="/catalogo" className="btn-secondary border-white text-white hover:border-gold-400">
              Ver catálogo
            </Link>
          </div>
        </div>
      </section>

      <section className="container-app py-16">
        <h2 className="font-serif text-2xl font-semibold">Modelos destacados</h2>
        <div className="mt-8 grid grid-cols-2 gap-6 sm:grid-cols-4">
          {featured.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
        {featured.length === 0 && (
          <p className="mt-4 text-sm text-neutral-500">
            Aún no hay productos en la base de datos. Corre <code>npm run db:seed</code> para cargar el catálogo.
          </p>
        )}
      </section>

      <section className="bg-neutral-50 py-16">
        <div className="container-app grid items-center gap-10 sm:grid-cols-2">
          <div>
            <h2 className="font-serif text-2xl font-semibold">¿Cuánto cuesta tu cocina?</h2>
            <p className="mt-4 text-neutral-600">
              Mide tus superficies, sube una foto de tu cocina actual y elige el modelo de piedra. Te damos un
              estimado al instante, sin compromiso.
            </p>
            <Link href="/cotizador" className="btn-primary mt-6">
              Empezar cotización
            </Link>
          </div>
          <div className="relative aspect-video overflow-hidden rounded-lg bg-neutral-200">
            <Image
              src="/images/products/prada-green.webp"
              alt="Ejemplo de piedra sinterizada Prada Green"
              fill
              className="object-cover"
            />
          </div>
        </div>
      </section>
    </div>
  );
}
