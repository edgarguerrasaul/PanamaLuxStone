"use client";

// Carrito de compras en memoria (zustand), persistido en localStorage
// del navegador del cliente — NO se usa localStorage directo de forma
// manual, la librería lo maneja internamente de forma segura para Next.js.
import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface CartItem {
  productId: string;
  slug: string;
  name: string;
  imageUrl: string;
  pricePerM2: number;
  areaM2: number;
}

interface CartState {
  items: CartItem[];
  addItem: (item: CartItem) => void;
  removeItem: (productId: string) => void;
  updateArea: (productId: string, areaM2: number) => void;
  clear: () => void;
  total: () => number;
}

export const useCart = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      addItem: (item) =>
        set((state) => {
          const existing = state.items.find((i) => i.productId === item.productId);
          if (existing) {
            return {
              items: state.items.map((i) =>
                i.productId === item.productId ? { ...i, areaM2: i.areaM2 + item.areaM2 } : i
              ),
            };
          }
          return { items: [...state.items, item] };
        }),
      removeItem: (productId) => set((state) => ({ items: state.items.filter((i) => i.productId !== productId) })),
      updateArea: (productId, areaM2) =>
        set((state) => ({
          items: state.items.map((i) => (i.productId === productId ? { ...i, areaM2 } : i)),
        })),
      clear: () => set({ items: [] }),
      total: () => get().items.reduce((sum, i) => sum + i.areaM2 * i.pricePerM2, 0),
    }),
    { name: "panamaluxstone-cart" }
  )
);
